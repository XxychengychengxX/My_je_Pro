package oj2.oj2_3;


import java.util.Scanner;

public class Main1 {
    public static void main(String[] args) {
        Scanner cinScanner = new Scanner(System.in);
        String method = cinScanner.nextLine();
        int num = cinScanner.nextInt();//行数

        double[][] res = new double[num][4];
        for (int i = 0; i < num; i++) {
            res[i][0] = cinScanner.nextDouble();
            res[i][1] = cinScanner.nextDouble();
            res[i][2] = cinScanner.nextDouble();
            res[i][3] = cinScanner.nextDouble();
        }
        Complex[] a = new Complex[num];
        Complex[] b = new Complex[num];
//		for(int i=0;i<num;i++) {
//			a[i].real=0.0;
//			a[i].fake=0.0;
//			b[i].real=0.0;
//			b[i].fake=0.0;
//		}
        for (int i = 0; i < num; i++) {
            switch (method) {
                case "add" -> {
                    add(a, res, i);

                }
                case "sub" -> {
                    sub(a, res, i);

                }
                case "mul" -> {
                    mul(a, res, i);
                }
                case "div" -> {
                    div(a, res, i);
                }
                default -> throw new IllegalArgumentException("Unexpected value: " + method);
            }
        }

        for (int i = 0; i < num-1; i++) {
            if (method.equals("div") && !a[i].flag) {//除法
                System.out.println("Error No : 1001");
                System.out.println("Error Message : Divide by zero.");
            } else {//其他情况
                if (a[i].fake >= 0) {
                    System.out.println(String.format("%.1f", a[i].real) + "+" + String.format("%.1f", a[i].fake) + "i");
                } else {
                    System.out.println(String.format("%.1f%.1f", a[i].real, a[i].fake) + "i");
                }
            }
        }
        if (method.equals("div") && !a[a.length-1].flag) {//除法
            System.out.println("Error No : 1001");
            System.out.println("Error Message : Divide by zero.");
        } else {//其他情况
            if (a[a.length-1].fake >= 0) {
                System.out.print(String.format("%.1f", a[a.length-1].real) + "+" + String.format("%.1f", a[a.length-1].fake) + "i");
            } else {
                System.out.print(String.format("%.1f%.1f", a[a.length-1].real, a[a.length-1].fake) + "i");
            }
    }}

    public static void add(Complex[] res, double[][] a, int cnt) {
        res[cnt] = new Complex(0.0, 0.0);
        res[cnt].real = a[cnt][0] + a[cnt][2];
        res[cnt].fake = a[cnt][1] + a[cnt][3];
    }

    public static void sub(Complex[] res, double[][] a, int cnt) {
        res[cnt] = new Complex(0.0, 0.0);
        res[cnt].real = a[cnt][0] - a[cnt][2];
        res[cnt].fake = a[cnt][1] - a[cnt][3];
    }

    public static void mul(Complex[] res, double[][] a, int cnt) {
        res[cnt] = new Complex(0.0, 0.0);
        res[cnt].real = a[cnt][0] * a[cnt][2] - a[cnt][1] * a[cnt][3];
        res[cnt].fake = a[cnt][0] * a[cnt][3] + a[cnt][1] * a[cnt][2];
    }

    public static void div(Complex[] res, double[][] a, int cnt) {
        res[cnt] = new Complex(0.0, 0.0);
        double mother = a[cnt][2] * a[cnt][2] + a[cnt][3] * a[cnt][3];
        if (mother == 0) {
            res[cnt].flag = false;
        } else {
            res[cnt].real = (a[cnt][0] * a[cnt][2] + a[cnt][1] * a[cnt][3]) / mother;
            res[cnt].fake = (a[cnt][1] * a[cnt][2] - a[cnt][0] * a[cnt][3]) / mother;
        }

    }

    public static class Complex {
        //		public Main(double d, double e) {
//			// TODO Auto-generated constructor stub
//		}
        double real;//实部
        double fake;//虚部
        boolean flag;

        public Complex(double real, double fake) {
            this.real = real;
            this.fake = fake;
            this.flag = true;
        }
    }

    public static class ComplexdivException {
        String code;
        String message;
    }
}

