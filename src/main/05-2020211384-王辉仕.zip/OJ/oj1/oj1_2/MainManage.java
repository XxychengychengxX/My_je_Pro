package oj1.oj1_2;

import java.util.ArrayList;


public class MainManage {
    private MainManage() {

    }


    public static void studentmanage_add(ArrayList<Main> s, Main s1) {
        int flag = 0;

        for (Main a : s
        ) {
            if (a.equals(s1)) {
                System.out.println("Students already exist");
                flag = 1;
                break;
            }
        }

        if (flag == 0) {
            s.add(s1);
            System.out.println("Add success");
        }

    }

    public static void studentmanage_delete(ArrayList<Main> s, String sequence) {

        int flag = 0;
        for (Main s1 : s
        ) {
            String k1 = s1.getSequences();
            if (k1.equals(sequence)) {
                s.remove(s1);
                flag = 1;
                System.out.println("Delete success");
                break;
            }
        }
        if (flag == 0) {
            System.out.println("Students do not exist");

        }
    }

    public static void studentmanage_update(ArrayList<Main> s, String sequence, int math, int english, int java) {
        int flag = 0;
        for (Main s1 : s
        ) {
            String k1 = s1.getSequences();
            if (k1.equals(sequence)) {
                s1.setEnglish(english);
                s1.setJava(java);
                s1.setMath(math);
                flag = 1;
                System.out.println("Update success");
                break;
            }
        }
        if (flag == 0) {
            System.out.println("Students do not exist");
        }
    }

    public static void studentmanage_display(ArrayList<Main> s, String sequence) {
        int flag = 0;
        for (Main i : s
        ) {

            if (i.getSequences().equals(sequence)) {
                double sum;
                sum = ((double) i.getEnglish() + i.getJava() + i.getMath()) / 3;
                flag = 1;
                System.out.println("Student ID:" + i.getSequences());
                System.out.println("Name:" + i.getName());
                System.out.println("Average Score:" + String.format("%.1f", sum));
                break;
            }

        }
        if (flag == 0)
            System.out.println("Students do not exist");
    }
}


