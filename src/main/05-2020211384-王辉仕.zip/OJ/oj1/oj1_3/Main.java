package oj1.oj1_3;

import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        try {
            int i = input.nextInt();
//            if (i < 1 || i > 10) {
//                throw new Exception();
//            }
            for (int j = 0; j < i; j++) {
                int even = input.nextInt();
//                if ((even < 0 || even > 1018)) {
//                    throw new Exception();
//                }
                int odds = input.nextInt();
//                if ((odds < 0 || odds > 1018)) {
//                    throw new Exception();
//                }
                if (Math.abs(even - odds) >= 2) {
                    System.out.println("GG");
                } else
                    System.out.println("MM");
            }
        } catch (Exception e) {
            System.out.println("input data error");
            System.exit(0);
        }

//        Scanner input = new Scanner(System.in);
//        try {
//            int i = input.nextInt();
////            if (i < 1 || i > 10) {
////                throw new Exception();
////            }
//            int[] arry = new int[2 * i];
//            for (int j = 0; j < arry.length; j++) {
//                arry[j] = input.nextInt();
//            }
//            int even, odds;
//            for (int k = 0; k < arry.length; k += 2) {
//                even = arry[k];
//                odds = arry[k + 1];
////                if ((even < 0 || even > 1018)) {
////                    throw new Exception();
////                }
////                if ((odds < 0 || odds > 1018)) {
////                    throw new Exception();
////                }
//                if (Math.abs(even - odds) >= 2) {
//                    System.out.println("GG");
//                } else
//                    System.out.println("MM");
//            }
//        } catch (Exception e) {
//            System.out.println("input data error");
//            System.exit(0);
//        }
//    }

}}
// try {
//         Scanner scanner = new Scanner(System.in);
//         int num = scanner.nextInt();
//         if(num<1||num>10) {//对第一个数判断
//        System.out.println("Input data error");
//        }
//        else {
//        for(;num>0;num--){
//        int a = scanner.nextInt();
//        int b = scanner.nextInt();
//        if(a<0||a>1018||b<0||b>1018) {//范围出错
//        System.out.println("Input data error");
//        }
//        else if(Math.abs(a - b) <= 1 && (a > 0 || b > 0)) {//理想情况
//        System.out.println("MM");
//        }
//        else {
//        System.out.println("GG");
//        }
//        }
//        }
//        }
//        catch (Exception e) {
//        System.out.println("Input data error");
//        }