package homework.no12;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketImpl;

public class No12Service extends ServerSocket {

    public static JTextArea textArea = new JTextArea();

    public No12Service(SocketImpl impl) {
        super(impl);
    }

    public No12Service() throws IOException {
    }

    public No12Service(int port) throws IOException {
        super(port);
    }

    public No12Service(int port, int backlog) throws IOException {
        super(port, backlog);
    }

    public No12Service(int port, int backlog, InetAddress bindAddr) throws IOException {
        super(port, backlog, bindAddr);
    }

    public static void main(String[] args) throws IOException {
        No12Service no12Service = new No12Service(8888);


        //搞窗口
        JFrame jFrame = new JFrame();
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setVisible(true);
        jFrame.setSize(600, 800);
        jFrame.setLocationRelativeTo(null);
        textArea.setFont(new Font("楷体", Font.PLAIN, 30));
        textArea.setBounds(200,400,200,300);
        textArea.setColumns(30);
        textArea.setEditable(false);
        textArea.setRows(10);
        textArea.setVisible(true);
        Container c = jFrame.getContentPane();

        c.setLayout(new FlowLayout());
        c.add(textArea);
        c.validate();


//交给一个线程，高并发性能不行 ，可以改成进程池
        /*ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(5, 8, 10, TimeUnit.MINUTES,
                new ArrayBlockingQueue<>(3), Executors.defaultThreadFactory(), new ThreadPoolExecutor.AbortPolicy() {
        });*/
        int i=0;
        String[] strings = {"小明", "小黄", "小李"};
        while (i<3) {
            Socket accept = no12Service.accept();
           new Thread(new no12(accept),strings[i++]).start();
//            else  new Thread(new no12(accept)).start();
            //threadPoolExecutor.execute(new no12(accept));
        }

    }


}