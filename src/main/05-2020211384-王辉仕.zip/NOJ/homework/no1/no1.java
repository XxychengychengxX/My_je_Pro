package homework.no1;
/*1．产生一个随机数，输出其小数部分四舍五入,开方，平方。再输出π和自然常数e。*/
public class no1 {
    public static void main(String[] args) {
        double i = Math.random() * 10;
        int j = (int) (i % 10);
        System.out.println(j);
        System.out.println(Math.sqrt(j));
        System.out.println(Math.pow(j, 2));
        System.out.println(Math.PI);
        System.out.println(Math.E);
    }
}
