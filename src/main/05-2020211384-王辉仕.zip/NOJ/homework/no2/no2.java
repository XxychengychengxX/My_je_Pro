package homework.no2;

import java.util.Arrays;
/*数组复制*/
public class no2 {
    public static void main(String[] args) {
        double[] ints = new double[50];
        for (int i = 0; i < 50; i++)
            ints[i] = Math.random() * (-10) + 5;
        double[] doubles = new double[50];
        double[] doubles1 = new double[50];
        double[] doubles2 = new double[50];
        System.arraycopy(ints, 0, doubles, 0, doubles.length);
        doubles1 = Arrays.copyOf(ints, doubles1.length);
        doubles2=Arrays.copyOfRange(ints,0,doubles2.length);
        System.out.println(Arrays.toString(doubles));
        System.out.println(Arrays.toString(doubles1));
        System.out.println(Arrays.toString(doubles2));
    }

}
