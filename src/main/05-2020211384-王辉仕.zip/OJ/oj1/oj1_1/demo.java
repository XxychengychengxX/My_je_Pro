package oj1.oj1_1;

import java.util.InputMismatchException;
import java.util.Scanner;

public class demo {
    public static void main(String[] args) throws InputMismatchException {
        Scanner i = new Scanner(System.in);
        try {
            int n = i.nextInt();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
