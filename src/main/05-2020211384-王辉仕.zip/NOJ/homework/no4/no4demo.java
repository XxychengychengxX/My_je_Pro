package homework.no4;

public class no4demo {
    public static void main(String[] args) {
         
        no4.Patient april=new no4.Patient();
        april.setName("zhangli");
        april.setSex('f');
        april.setAge(330);
        april.setWeight((float) 154.72);
        april.setAllergies(true);
        System.out.println("name：  "+april.getName());
        System.out.println("sex:  "+april.getSex());
        System.out.println("age:   "+april.getAge());
        System.out.println("weight:  "+april.getWeight());
        System.out.println("allergies:  "+april.isAllergies());
        System.out.println(april);
    }
}
