package oj2.oj2_2;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Myqueue {
    public Queue<Integer> queue;
    public ArrayList<Integer> popnums;

    public Myqueue(ArrayList<Integer> integers) {
        this.queue = new LinkedList<Integer>();
        for (Integer integer : integers) {
            this.queue.offer(integer);
        }
        this.popnums = new ArrayList<>();

    }

    /* public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);
         Queue<Integer> integers = new LinkedList<>();
         ArrayList<Integer> popnums = new ArrayList<>();
         try {
             int i = scanner.nextInt();
             for (int j = 0; j < i; j++)
                 integers.offer(scanner.nextInt());
             String s1 = "in", s2 = "out";
             for (int j = 0; j < 2; j++) {
                 String input1 = scanner.next();
                 if (input1.equals(s2)) {
                     i = scanner.nextInt();
                     for (int k = 0; k < i; k++)
                         if (!integers.isEmpty())
                             popnums.add(integers.remove());
                 } else {
                     while (scanner.hasNextInt())
                         integers.offer(scanner.nextInt());
                 }

             }

         } catch (Exception e) {
             e.printStackTrace();
         } finally {
             if (integers.isEmpty())
                 System.out.println("len = 0");
             else {
                 System.out.print("len = " + integers.size() + ", ");
                 System.out.println("data = " + integers);
             }
             if (popnums.isEmpty())
                 System.out.println("len = 0");
             else {
                 System.out.print("len = " + popnums.size() + ", ");
                 System.out.println("data = " + popnums);
             }
         }
     }*/
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Integer> integers = new ArrayList<>();
        try {
            int i = scanner.nextInt();
            for (int j = 0; j < i; j++)
                integers.add(scanner.nextInt());
            Myqueue myQueue = new Myqueue(integers);
            String s2 = "out";
            for (int j = 0; j < 2; j++) {
                if (j == 0)
                    scanner.nextLine();
                String s1 = scanner.nextLine();
                Scanner scanner1 = new Scanner(s1);
                if (scanner1.next().equals(s2))
                    myQueue.out(scanner1.nextInt());
                else {
                    integers.clear();
                    while (scanner1.hasNextInt())
                        integers.add(scanner1.nextInt());
                    myQueue.in(integers);
                }
            }
            myQueue.display();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void out(int num) {
        for (int k = 0; k < num; k++)
            if (!this.queue.isEmpty())
                this.popnums.add(this.queue.remove());
    }

    public void in(ArrayList<Integer> integers) {
        for (Integer integer : integers) this.queue.offer(integer);
    }

    public void display() {
        if (this.queue.isEmpty())
            System.out.println("len = 0");
        else {
            System.out.print("len = " + this.queue.size() + ", data = ");
            while (this.queue.size()!=1)
                System.out.print(this.queue.remove()+ " ");
            System.out.println(this.queue.remove());
        }
        if (this.popnums.isEmpty())
            System.out.println("len = 0");
        else {
            System.out.print("len = " + this.popnums.size() + ", data = ");
            while (this.popnums.size()!=1)
                System.out.print(this.popnums.remove(0)+ " ");
            System.out.println(this.popnums.remove(0));
        }
    }
}
