package oj1.oj1_2;

public class sdemo {
    public static void main(String[] args) {
        String i="woaizhongguo";


    }
}
