package homework.no5;

import java.util.Scanner;
public class no5 {
    public static void main(String[] args) {
        Scanner Scanner = new Scanner(System.in);
        String method = Scanner.nextLine();
       // String method = "div";
        int num = Scanner.nextInt();//行数
      //  int num = 100;
        Complex[] a = new Complex[num];
        double[][] res = new double[num][4];
        for (int i = 0; i < num; i++) {
           res[i][0] = Scanner.nextDouble();
            res[i][1] = Scanner.nextDouble();
            res[i][2] = Scanner.nextDouble();
            res[i][3] = Scanner.nextDouble();

//            res[i][0] = Math.random()*(-500)+1000;
//            res[i][1] = Math.random()*(-500)+1000;
//            res[i][2]=Math.random()<0.5? Math.random()*(-500)+1000: 0;
//            res[i][3] = Math.random()<0.5? Math.random()*(-500)+1000: 0;
            a[i] = new Complex(0.0, 0.0);

        }
        switch (method) {
            case "add" -> add(a, res, num);
            case "sub" -> sub(a, res, num);
            case "mul" -> mul(a, res, num);
            case "div" -> div(a, res, num);
            default -> throw new IllegalArgumentException("Unexpected value: " + method);
        }
        for (int i = 0; i < num ; i++) {
            if (!a[i].flag) {//除法
                System.out.println("Error No : 1001");
                System.out.println("Error Message : Divide by zero.");
            } else {//其他情况
                if (a[i].image >= 0) {
                    System.out.printf("%.1f+%.1fi", a[i].real, a[i].image);
                    System.out.print("\n");
                } else {
                    System.out.printf("%.1f%.1fi", a[i].real, a[i].image);
                    System.out.print("\n");
                }
            }
        }
        /*if (method.equals("div") && !a[a.length - 1].flag) {//除法
            System.out.println("Error No : 1001");
            System.out.print("Error Message : Divide by zero.");
        } else {//其他情况
            if (a[a.length - 1].image >= 0) {
                System.out.printf("%.1f+%.1fi", a[a.length - 1].real, a[a.length - 1].image);
            } else {
                System.out.printf("%.1f%.1fi", a[a.length - 1].real, a[a.length - 1].image);
            }
        }*/
    }

    public static void add(Complex[] res, double[][] a, int cnt) {
        for (int i = 0; i < cnt; i++) {
            res[i].real = a[i][0] + a[i][2];
            res[i].image = a[i][1] + a[i][3];
        }
    }

    public static void sub(Complex[] res, double[][] a, int cnt) {

        for (int i = 0; i < cnt; i++) {
            res[i].real = a[i][0] - a[i][2];
            res[i].image = a[i][1] - a[i][3];
        }
    }

    public static void mul(Complex[] res, double[][] a, int cnt) {
        // res[0] = new Complex(0.0, 0.0);
        for (int i = 0; i < cnt; i++) {
            res[i].real = a[i][0] * a[i][2] - a[i][1] * a[i][3];
            res[i].image = a[i][0] * a[i][3] + a[i][1] * a[i][2];
        }
    }

    public static void div(Complex[] res, double[][] a, int cnt) {
        // res[0] = new Complex(0.0, 0.0);
        for (int i = 0; i < cnt; i++) {
            if (a[i][2] == 0 && a[i][3] == 0)
                res[i].flag = false;
            else {
                res[i].real =
                        (a[i][0] * a[i][2] + a[i][1] * a[i][3]) / (Math.pow(a[i][2], 2) + Math.pow(a[i][3], 2));
                res[i].image = (a[i][1] * a[i][2] - a[i][0] * a[i][3]) / (Math.pow(a[i][2], 2) + Math.pow(a[i][3], 2));
            }

        }
    }

    public static class Complex {
        //		public Main(double d, double e) {
//			// TODO Auto-generated constructor stub
//		}
        double real;//实部
        double image;//虚部
        boolean flag;

        public Complex(double real, double image) {
            this.real = real;
            this.image = image;
            this.flag = true;
        }
    }

    public static class ComplexdivException {
        String code;
        String message;
    }
}

