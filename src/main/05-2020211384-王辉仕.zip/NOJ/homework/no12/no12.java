package homework.no12;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.text.SimpleDateFormat;

public class no12 implements Runnable {
    private Socket socket;
    public static String msg;
    public static String s;
    public no12(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
         //字节输入
            InputStream is = socket.getInputStream();
          //字符缓冲输入流
            BufferedReader br = new BufferedReader(new InputStreamReader(is));

            No12Service.textArea.append(Thread.currentThread().getName() + "上线了！！！\n");


            while ((msg = br.readLine()) != null) {

                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd " +
                        "HH:mm:ss");
                s = simpleDateFormat.format(System.currentTimeMillis());
               // No12Users.a.append(Thread.currentThread().getName() + "  " + s + "\n" + msg + "\n");
                No12Service.textArea.append(Thread.currentThread().getName() + "  " + s + "\n" + msg + "\n");



            }
        } catch (Exception e) {
            No12Service.textArea.append(Thread.currentThread().getName() + "下线了！！！\n");
        }
    }
    public static String retext(){
        return msg;
    }

}

