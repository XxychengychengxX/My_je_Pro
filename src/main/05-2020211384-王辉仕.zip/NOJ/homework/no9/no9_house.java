package homework.no9;

public class no9_house {
    int huowu;

    public no9_house(int huowu) {
        this.huowu = huowu;
    }

    public no9_house() {
    }

    public int getHuowu() {
        return huowu;
    }

    public void setHuowu(int huowu) {
        this.huowu = huowu;
    }

    public boolean input(int i) {

        if (i < 1 || i > 20||this.huowu+i>50) {
            System.out.println("-----------");
            System.out.println(Thread.currentThread().getName()+"即将存取，当前货物量 ："+this.huowu);
            System.out.println(Thread.currentThread().getName()+"存取失败，数据有误! 当前货物量 ："+this.huowu);
            return false;
        }
        System.out.println("-----------");
        System.out.println(Thread.currentThread().getName()+"即将存取，当前货物量 ："+this.huowu);
        this.huowu += i;
        System.out.println(Thread.currentThread().getName()+"存取成功，当前货物量 ："+this.huowu);
        return true;
    }

    public boolean output(int i) {

        if (i < 1 || i > 20||this.huowu-i<0) {
            System.out.println("-----------");
            System.out.println(Thread.currentThread().getName()+"即将存取，当前货物量 ："+this.huowu);
            System.out.println(Thread.currentThread().getName()+"存取失败，数据有误! 当前货物量 ："+this.huowu);
            return false;
        }
        System.out.println("-----------");
        System.out.println(Thread.currentThread().getName()+"即将存取，当前货物量 ："+this.huowu);
        this.huowu -= i;
        System.out.println(Thread.currentThread().getName()+"存取成功，当前货物量 ："+this.huowu);
        return true;
    }
}
