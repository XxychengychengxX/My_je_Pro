package homework.no9;

import java.util.concurrent.CountDownLatch;

public class no9demo {
    CountDownLatch countDownLatch = new CountDownLatch(1);
    CountDownLatch countDownLatch1 = new CountDownLatch(1);
    CountDownLatch countDownLatch2 = new CountDownLatch(1);
    CountDownLatch countDownLatch3 = new CountDownLatch(1);
    CountDownLatch countDownLatch4 = new CountDownLatch(1);
    CountDownLatch countDownLatch5 = new CountDownLatch(1);
    private final no9_house no9_house = new no9_house(0);
    public no9demo() {
    }

    public static void main(String[] args) {
        new no9demo().start();
    }
    public void start() {
        Runnable input1 = new input1();
        Thread thread1 = new Thread(input1,"存货物1号线程" );
        Runnable input2= new input2();
        Thread thread2 = new Thread(input2,"存货物2号线程" );
        Runnable output3 = new output3();
        Thread thread3 = new Thread(output3,"取货物3号线程" );
        Runnable output4= new output4();
        Thread thread4 = new Thread(output4,"取货物4号线程" );

        thread1.start();
        thread2.start();
        thread3.start();
        thread4.start();
    }
    public class input1 implements Runnable {
        public input1() {
        }

        @Override
        public void run() {

                no9_house.input(20);
                no9_house.input(21);
                countDownLatch.countDown();
                try {
                    countDownLatch4.await();
                    no9_house.input(5);
                    no9_house.input(0);
                    countDownLatch5.countDown();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }

    }

    public class input2 implements Runnable {
        public input2() {
        }

        @Override
        public void run() {
             {
                 try {
                     countDownLatch.await();
                     no9_house.input(20);
                     countDownLatch1.countDown();
                     countDownLatch3.await();
                     no9_house.input(20);
                     countDownLatch4.countDown();
                 } catch (InterruptedException e) {
                     e.printStackTrace();
                 }

            }
        }
    }


    public class output3 implements Runnable {
        public output3() {
        }

        @Override
        public void run() {
                try {
                    countDownLatch1.await();
                    no9_house.output(-1);
                    no9_house.output(5);
                    countDownLatch2.countDown();
                    countDownLatch5.await();
                    no9_house.output(20);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }




        }
    }

    public class output4 implements Runnable {
        public output4() {
        }

        @Override
        public void run() {
            try {
                countDownLatch2.await();
                no9_house.output(1);
                countDownLatch3.countDown();
        } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
}
}
