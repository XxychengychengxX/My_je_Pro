package homework.no6;

public class no6_display_ads implements no6_display {
    String ads;

    public String getAds() {
        return ads;
    }

    public void setAds(String ads) {
        this.ads = ads;
    }

    public no6_display_ads(String ads) {
        this.ads = ads;
    }

    @Override
    public void display() {
        System.out.println("广告消息：" + this.ads);
    }
}
