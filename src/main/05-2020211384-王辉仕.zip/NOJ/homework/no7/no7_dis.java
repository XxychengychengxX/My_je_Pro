package homework.no7;

public class no7_dis {
    public static void main(String[] args) throws InterruptedException, no7 {
        try {
            errortest();
        } catch (no7  e) {
            System.out.println( e.getMessage());
            System.out.println("重启");
            Thread.sleep(2000);
            e.restart();
        }
    }
    public static void errortest() throws no7 {
        try {
            System.out.println(1/0);
        } catch (Exception e) {
           throw  new no7("寄啦");
        }
    }
    public static class control {
        public control() {
        }
    }

    public static class no7 extends Throwable {


        public no7() {
        }

        public no7(String message) {
            super(message);

        }

        public no7(String message, Throwable cause) {
            super(message, cause);
        }

        public no7(Throwable cause) {
            super(cause);
        }

        public no7(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
            super(message, cause, enableSuppression, writableStackTrace);
        }

        public void restart() throws no7, InterruptedException {
            main(null);
        }

    }

}
