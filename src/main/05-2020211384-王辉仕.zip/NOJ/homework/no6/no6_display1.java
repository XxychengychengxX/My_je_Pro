package homework.no6;

public class no6_display1 {
    public static void main(String[] args) {
    no6_display[] displays=new no6_display[]{new no6_display_cars(80),new no6_display_ads("welcome to xxx"),new no6_display_imformation("There is")};
        for (no6_display display : displays) {
            display.display();
        }
    }
}
