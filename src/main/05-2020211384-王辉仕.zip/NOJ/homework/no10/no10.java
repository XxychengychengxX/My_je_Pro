package homework.no10;

import javax.swing.*;
import java.awt.*;

public class no10 {
    public static void main(String[] args) {
        new creatframe().creat();
    }
    public static class creatframe {
        public JFrame creat() {
            JFrame i = new JFrame("第十题");
            i.setVisible(true);
            i.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            i.setSize(600,800);
            i.setLocationRelativeTo(null);
            Container c = i.getContentPane();

            //标签
            JLabel jLabel = new JLabel("我爱java，java爱我;我爱中国，中国爱我");
            jLabel.setFont(new Font("楷体",Font.PLAIN,30));




            Integer[] integer = {10,15,20,25,30,35,40};
            JComboBox<Integer> integerJComboBox = new JComboBox<>(integer);
            integerJComboBox.setEditable(true);

            integerJComboBox.setBounds(200,200,200,50);

            integerJComboBox.addActionListener(e -> jLabel.setFont(new Font("楷体",Font.PLAIN, (Integer) integerJComboBox.getSelectedItem())));

            c.setLayout(new FlowLayout());
            c.add(jLabel);
            c.add(integerJComboBox);
            c.validate();


            return i;
        }
    }
}
