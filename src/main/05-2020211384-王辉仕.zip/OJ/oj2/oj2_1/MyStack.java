package oj2.oj2_1;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

public class MyStack {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LinkedList<Integer> integers = new LinkedList<>();
        ArrayList<Integer> popnums = new ArrayList<>();
        try {
            int i = scanner.nextInt();
            for (int j = 0; j < i; j++)
                integers.push(scanner.nextInt());
            String s1 = "pop";
            for (int j = 0; j < 2; j++) {
                if (j == 0)
                    scanner.nextLine();
                String s3 = scanner.nextLine();
                Scanner scanner1 = new Scanner(s3);
                if (scanner1.next().equals(s1)) {
                    i = scanner1.nextInt();
                    for (int k = 0; k < i; k++)
                        if (!integers.isEmpty())
                            popnums.add(integers.pop());
                } else
                    while (scanner1.hasNextInt())
                        integers.push(scanner1.nextInt());
            }

//            String input2 = scanner.next();
//            if (input2.equals(s1)) {
//                i = scanner.nextInt();
//                for (int j = 0; j < i; j++)
//                    if (!integers.isEmpty())
//                        popnums.add(integers.pop());
//            } else if (input2.equals(s2))
//                while (scanner.hasNextInt())
//                    integers.push(scanner.nextInt());

            //        Integer[] a=integers.toArray(new Integer[1]);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (integers.isEmpty())
                System.out.println("len = 0");
            else {
                System.out.print("len = " + integers.size() + ", data = ");
                while (integers.size() != 1)
                    System.out.print(integers.removeLast() + " ");
                System.out.println(integers.remove());
            }
            if (popnums.isEmpty())
                System.out.println("len = 0");
            else {
                System.out.print("len = " + popnums.size() + ", data = ");
                while (popnums.size() != 1)
                    System.out.print(popnums.remove(0) + " ");
                System.out.println(popnums.remove(0));
            }
        }


    }


}
