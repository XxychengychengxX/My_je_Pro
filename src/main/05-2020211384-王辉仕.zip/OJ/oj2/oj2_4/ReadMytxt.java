package oj2.oj2_4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class ReadMytxt {
    public static void main(String[] args) {
        Scanner cin = new Scanner(System.in);
        try {
            File file = new File("my.txt");
            FileOutputStream f1 = new FileOutputStream(file);
            String temp1 = cin.nextLine();
            f1.write(temp1.getBytes(StandardCharsets.UTF_8));
            f1.close();
//		选择输入格式

            String temp = cin.nextLine();
            String temp3 = cin.nextLine();
            String temp4 = "";
            switch (temp) {
                case "w", "w+" -> {
                    FileOutputStream f3 = new FileOutputStream(file);
                    f3.write(temp3.getBytes(StandardCharsets.UTF_8));
                    temp4 = temp3;
                }
                case "x", "x+", "r" -> {
                    temp4 = temp1;
                }
                case "a", "a+" -> {
                    temp4 = temp1 + temp3;
                }
                case "r+" -> {
                    if (temp3.length() > temp1.length())
                        temp4 = temp3;
                    else {
                        String temp5 = temp1.substring(temp3.length());
                        temp4 = temp3 + temp5;
                    }
                }
            }
//		输出结果
            FileInputStream f2 = new FileInputStream(file);
//		byte[] buff2 = cin.nextLine().getBytes();

//            for (int i = 0; i < file.length(); i++)
//                ch = (char) (f2.read());//循环读取字符
            System.out.print(temp4);
            f2.close();
        } catch (Exception e) {
            // TODO: handle exception
        }
    }
}


/*public class ReadMytxt {


    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);


        File file1 = new File("my.txt");
//        if (!file1.exists())
//            file1.createNewFile();
        try
//                (OutputStream os = new BufferedOutputStream(new FileOutputStream(file1));
//                InputStream is = new BufferedInputStream(new FileInputStream(fliename));
//                OutputStream osappend = new BufferedOutputStream(new FileOutputStream(fliename, true));
//        )
        {

            String fliename = scanner.nextLine();
            OutputStream os = new BufferedOutputStream(new FileOutputStream(file1));
            os.write(fliename.getBytes());
            os.close();
            String string = scanner.nextLine();
            switch (string) {
                case "w", "w+", "r+" -> {
                    OutputStream os1 = new BufferedOutputStream(new FileOutputStream(fliename));
                    os1.write(scanner.nextLine().getBytes(StandardCharsets.UTF_8));
                    os1.close();
                }

                case "a", "a+" -> {
                    OutputStream osappend = new BufferedOutputStream(new FileOutputStream(fliename, true));
                    osappend.write(scanner.nextLine().getBytes(StandardCharsets.UTF_8));
                    osappend.close();
                }
            }
            BufferedReader is = new BufferedReader(new FileReader(fliename));
            String line;
            ArrayList<String> arrayList = new ArrayList<>();
            while ((line = is.readLine()) != null)
                arrayList.add(line);
            while (arrayList.size() != 1)
                System.out.println(arrayList.remove(0));
            System.out.print(arrayList.remove(0));
            is.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}*/
