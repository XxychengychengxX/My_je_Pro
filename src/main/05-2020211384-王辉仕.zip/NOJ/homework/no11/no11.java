package homework.no11;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;

public class no11 {
    public static void main(String[] args) {
        JFrame i = new JFrame("第十一题");
        i.setVisible(true);
        i.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        i.setSize(600, 800);
        i.setLocationRelativeTo(null);
        Container c = i.getContentPane();

        JMenuBar jMenuBar = new JMenuBar();
        jMenuBar.setVisible(true);
        jMenuBar.setBounds(0, 0, 30, 20);

        //一级菜单内容
        JMenu file = new JMenu("File");
        JMenu type = new JMenu("Type");

        //二级菜单内容
        JMenuItem open = new JMenuItem("打开");
        JMenuItem exit = new JMenuItem("关闭");

        JRadioButtonMenuItem jCheckBoxMenuItem0 = new JRadioButtonMenuItem("*", null, true);
        JRadioButtonMenuItem jCheckBoxMenuItem1 = new JRadioButtonMenuItem("txt", null, false);
        JRadioButtonMenuItem jCheckBoxMenuItem2 = new JRadioButtonMenuItem("word", null, false);

        //按钮组
//        ButtonGroup buttonGroup = new ButtonGroup();
//        buttonGroup.add(jCheckBoxMenuItem1);
//        buttonGroup.add(jCheckBoxMenuItem2);


        //二级菜单添加入一级菜单
        file.add(open);
        file.addSeparator();
        file.add(exit);
        type.add(jCheckBoxMenuItem0);
        type.add(jCheckBoxMenuItem2);
        type.add(jCheckBoxMenuItem1);

        JFileChooser jFileChooser = new JFileChooser();
        jFileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
        jFileChooser.setDialogTitle("请选择。。。。");
        jFileChooser.setCurrentDirectory(new File("."));
        jFileChooser.removeChoosableFileFilter(jFileChooser.getAcceptAllFileFilter());//



        open.addActionListener(e -> jFileChooser.showOpenDialog(null));

        jCheckBoxMenuItem0.addActionListener(e -> {
            if (jCheckBoxMenuItem0.isSelected()) {
                jFileChooser.resetChoosableFileFilters();
                jFileChooser.addChoosableFileFilter(new FileNameExtensionFilter("ALL(*)", "*"));
                jCheckBoxMenuItem1.setSelected(false);
                jCheckBoxMenuItem2.setSelected(false);
            }
        });

        jCheckBoxMenuItem2.addActionListener(e -> {
            FileNameExtensionFilter fileNameExtensionFilter = new FileNameExtensionFilter("Word(*" +
                    ".doc," +
                    "*。docx）", "doc", "docx");
/*FileFilter fileFilter = new FileFilter() {
                @Override
                public boolean accept(File f) {
                    if (f.isDirectory()) {
                        return true;
                    }
                    String fileName = f.getName().toLowerCase();
                     if (fileName.endsWith(".doc")||fileName.endsWith(".docx")) {
                        return true;
                    }
                    return false;
                }
            };*/
            if (!jCheckBoxMenuItem2.isSelected()&&!jCheckBoxMenuItem1.isSelected())
                jFileChooser.resetChoosableFileFilters();
            else if (!jCheckBoxMenuItem2.isSelected()&&jCheckBoxMenuItem1.isSelected())
                jFileChooser.removeChoosableFileFilter(fileNameExtensionFilter);
            else {
                jFileChooser.addChoosableFileFilter(fileNameExtensionFilter);
                jCheckBoxMenuItem0.setSelected(false);
            }
//            if (jCheckBoxMenuItem2.isSelected())
//                System.out.println("按下一次");
        });

        jCheckBoxMenuItem1.addActionListener(e -> {
            FileNameExtensionFilter txt = new FileNameExtensionFilter("text(*.txt)"
                    , "txt");
            if (!jCheckBoxMenuItem1.isSelected()&&!jCheckBoxMenuItem2.isSelected())
                jFileChooser.resetChoosableFileFilters();
            else if (!jCheckBoxMenuItem1.isSelected()&&jCheckBoxMenuItem2.isSelected())
                jFileChooser.removeChoosableFileFilter(txt);
            else {
                jFileChooser.addChoosableFileFilter(txt);
                jCheckBoxMenuItem0.setSelected(false);
            }
//            if (jCheckBoxMenuItem1.isSelected())
//            System.out.println("按下一次");
        });


        jMenuBar.add(file);
        jMenuBar.add(type);
        c.add(jMenuBar);
        c.validate();
    }
}
