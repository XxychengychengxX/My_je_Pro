package oj1.oj1_4;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner i = new Scanner(System.in);
        int n = i.nextInt();
        int[] ints = new int[n];
        for (int j = 0; j < n; j++) {
            ints[j] = i.nextInt();
        }
        for (int k = 1; k < n; k++) {
            for (int j = 0; j < k; j++) {

                if (ints[j] > ints[k]) {
                    int temp = ints[k];
                    ints[k] = ints[j];
                    ints[j] = temp;
                }
            }
            for (int j = 0; j < n - 1; j++) {
                System.out.print(ints[j] + " ");
            }

            System.out.println(ints[n-1]);
        }

    }
}
