package oj1.oj1_2;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public String name, sequences;
    public int math, english, Java;



    public Main(String sequences, String name, int math, int english, int java) {
        this.name = name;
        this.sequences = sequences;
        this.math = math;
        this.english = english;
        this.Java=java;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSequences() {
        return sequences;
    }

    public void setSequences(String sequences) {
        this.sequences = sequences;
    }

    public int getMath() {
        return math;
    }

    public void setMath(int math) {
        this.math = math;
    }

    public int getEnglish() {
        return english;
    }

    public void setEnglish(int english) {
        this.english = english;
    }

    public int getJava() {
        return Java;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Main student = (Main) o;
        return math == student.math && english == student.english && Java == student.Java && name.equals(student.name) && sequences.equals(student.sequences);
    }

    public void setJava(int java) {
        Java = java;
    }

    public static void main(String[] args) {
        ArrayList<Main> s = new ArrayList<>();
        int n, j;
        Scanner input = new Scanner(System.in);
        n = input.nextInt();
        for (int i = 0; i < n; i++) {
            j = input.nextInt();
            switch (j) {
                case 1 -> {
                    Main s1 = new Main(input.next(), input.next(), input.nextInt(), input.nextInt(), input.nextInt());
                    studentmanage_add(s, s1);
                }
                case 2 -> studentmanage_delete(s, input.next());
                case 3 -> studentmanage_update(s, input.next(), input.nextInt(), input.nextInt(), input.nextInt());
                case 4 -> studentmanage_display(s, input.next());
            }
        }

    }
    public static void studentmanage_add(ArrayList<Main> s, Main s1) {
        int flag = 0;

        for (Main a : s
        ) {
            if (a.equals(s1)) {
                System.out.println("Students already exist");
                flag = 1;
                break;
            }
        }

        if (flag == 0) {
            s.add(s1);
            System.out.println("Add success ");
        }

    }

    public static void studentmanage_delete(ArrayList<Main> s, String sequence) {

        int flag = 0;
        for (Main s1 : s
        ) {
            String k1 = s1.getSequences();
            if (k1.equals(sequence)) {
                s.remove(s1);
                flag = 1;
                System.out.println("Delete success");
                break;
            }
        }
        if (flag == 0) {
            System.out.println("Students do not exist");

        }
    }

    public static void studentmanage_update(ArrayList<Main> s, String sequence, int math, int english, int java) {
        int flag = 0;
        for (Main s1 : s
        ) {
            String k1 = s1.getSequences();
            if (k1.equals(sequence)) {
                s1.setEnglish(english);
                s1.setJava(java);
                s1.setMath(math);
                flag = 1;
                System.out.println("Update success");
                break;
            }
        }
        if (flag == 0) {
            System.out.println("Students do not exist");
        }
    }

    public static void studentmanage_display(ArrayList<Main> s, String sequence) {
        int flag = 0;
        for (Main i : s
        ) {

            if (i.getSequences().equals(sequence)) {
                double sum;
                sum = ((double) i.getEnglish() + i.getJava() + i.getMath()) / 3;
                flag = 1;
                System.out.println("Student ID:" + i.getSequences());
                System.out.println("Name:" + i.getName());
                System.out.println("Average Score:" + String.format("%.1f",sum));
                break;
            }

        }
        if (flag == 0)
            System.out.println("Students do not exist");
    }
}


