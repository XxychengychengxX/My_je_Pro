package homework.no6;

public interface no6_display {
    public  void display();

}
