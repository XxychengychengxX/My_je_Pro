package homework.no8;

import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;

public class no8 {
    public static final control control = new control();

    public static void main(String[] args) {
        Callable<Void> a = new A();
        FutureTask<Void> AA = new FutureTask<>(a);
        new Thread(AA, "A线程").start();

        new Thread(new B(), "B线程").start();
        C c = new C();
        new Thread(c, "c线程").start();
    }

    public static class A implements Callable<Void> {
        public A() {
        }

        @Override
        public Void call() throws Exception {
            String s = Thread.currentThread().getName();
            System.out.println(s + "...start");
            synchronized (control) {
                control.wait();
            }
            System.out.println(s + "...end");
            return null;
        }
    }

    public static class B implements Runnable {
        public B() {
        }

        @Override
        public void run() {
            try {
                String s = Thread.currentThread().getName();
                System.out.println(s + "...start");
                synchronized (control) {
                    control.wait();
                    System.out.println(s + "...end");

                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }

    public static class C extends Thread {
        public C() {
        }

        @Override
        public void run() {
            String s = Thread.currentThread().getName();
            int num ;
            try {
                sleep(3000);
                System.out.println("现在运行的线程数目" + activeCount());
                synchronized (control) {
                    num = activeCount();
                    control.notifyAll();
                }

                while (activeCount() != num - 2) {
                    System.out.println("现在运行的线程数目" + activeCount());
                    sleep(2000);
                }
                System.out.println(s + "....end");
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

    }

    public static class control {
        public control() {
        }
    }

}



