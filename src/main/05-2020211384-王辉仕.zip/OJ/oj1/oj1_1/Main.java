package oj1.oj1_1;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // write your code here
        Scanner i = new Scanner(System.in);
        int n = 0;
        try {
            n = i.nextInt();
            if (n < 1 || n > 50) {
                System.out.println("Input data error");
                System.exit(0);
            } else
                fangzhen(n);
        } catch (Exception e) {
            System.out.println("Input data error");
            System.exit(0);
        }

    }


    public static void fangzhen(int n) {
        int count = 1;
        int[][] a = new int[n][n];
        shengcheng(a, 0, n - 1, 1);
        for (int[] i : a
        ) {
            for (int j : i
            ) {

                if (count == n) {
                    System.out.println(j);
                    count=1;
                } else {
                    System.out.printf("%d ", j);
                    count++;
                }
            }
        }

    }

    public static void shengcheng(int[][] a, int row_start, int colunm_start, int num) {
        int num1 = num;
        int row = row_start;
        int colunm = colunm_start;
        if (colunm_start == row_start) {
            a[colunm_start][row_start] = num1;
            return;
        } else if ((colunm_start <= row_start))
            return;
        else {
            while (row < colunm) {
                a[row++][colunm] = num1++;
            }
            while (colunm > row_start) {
                a[row][colunm--] = num1++;
            }
            while (row > colunm) {
                a[row--][colunm] = num1++;
            }
            while (colunm < colunm_start ) {
                a[row][colunm++] = num1++;
            }
            shengcheng(a, row_start + 1, colunm_start - 1, num1 );
        }
    }
}
