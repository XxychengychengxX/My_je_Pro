package homework.no12;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.io.PrintStream;
import java.net.*;

public class No12Users extends Socket {


    public No12Users(Proxy proxy) {
        super(proxy);
    }

    public No12Users(SocketImpl impl) throws SocketException {
        super(impl);
    }

    public No12Users(String host, int port) throws IOException {
        super(host, port);
    }

    public No12Users(InetAddress address, int port) throws IOException {
        super(address, port);
    }

    public No12Users(String host, int port, InetAddress localAddr, int localPort) throws IOException {
        super(host, port, localAddr, localPort);
    }

    public No12Users(InetAddress address, int port, InetAddress localAddr, int localPort) throws IOException {
        super(address, port, localAddr, localPort);
    }

    public No12Users(String host, int port, boolean stream) throws IOException {
        super(host, port, stream);
    }

    public No12Users(InetAddress host, int port, boolean stream) throws IOException {
        super(host, port, stream);
    }

    public static void main(String[] args) throws IOException {
        No12Users no12Users = new No12Users("192.168.3.4", 8888);

        PrintStream printStream = new PrintStream(no12Users.getOutputStream());

        //搞窗口
        JFrame jFrame = new JFrame();
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setVisible(true);
        jFrame.setSize(800,1000);
        jFrame.setLocationRelativeTo(null);

        Container c = jFrame.getContentPane();

        JTextArea jTextArea = new JTextArea();

        jTextArea.setEditable(true);
        jTextArea.setFont(new Font("楷体",Font.PLAIN,30));
        jTextArea.setBounds(500,700,200,100);
        jTextArea.setColumns(30);
        jTextArea.setRows(10);
        jTextArea.setVisible(true);
        JTextArea a = new JTextArea();
        JButton jButton = new JButton("离线");
        JButton jButton1 = new JButton("发送");
        a.setFont(new Font("楷体", Font.PLAIN, 30));
        a.setBounds(200,400,200,300);
        a.setColumns(30);
        a.setEditable(false);
        a.setRows(10);
        a.setVisible(true);
        c.setLayout(new FlowLayout());


      //  c.add(a);
        c.add(jTextArea);
        c.add(jButton);
        c.add(jButton1);
        c.validate();



        jButton.addActionListener(e -> System.exit(0));
        //发送事件
        jButton1.addActionListener(e -> {
            printStream.println(jTextArea.getText());

            jTextArea.setText(null);

//        Scanner scanner = new Scanner(System.in);
//        while (true){
//            printStream.println(scanner.nextLine());
//            printStream.flush();
//        }
    });
}
}

