package homework.no3;

public class no3 {
    public static void main(String[] args) {
        double a=Double.MAX_VALUE;
        double b=1/a;
        System.out.println(a);
        System.out.println(b);
        System.out.println("真正的e："+Math.E);
        System.out.println("近似的e："+Math.pow(1+b,a));
    }
}
