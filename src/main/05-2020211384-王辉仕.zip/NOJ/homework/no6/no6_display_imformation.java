package homework.no6;

public class no6_display_imformation implements no6_display {
    String imform;

    public no6_display_imformation(String imform) {
        this.imform = imform;
    }

    public String getImform() {
        return imform;
    }

    public void setImform(String imform) {
        this.imform = imform;
    }

    @Override
    public void display() {
        System.out.println("通知内容：" + this.imform);
    }
}
