package oj2.oj2_5;

import java.util.ArrayList;
import java.util.Scanner;

public class dangerous {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Integer> integers = new ArrayList<>();
        int i = scanner.nextInt();
        for (int j = 0; j < i; j++)
            integers.add(scanner.nextInt());
        integers.sort((o1, o2) -> o1 - o2);
        int sum = 0;
        for (int j = 0; j < integers.size() / 2 + 1; j++)
            sum += integers.get(j) / 2 + 1;
        System.out.println(sum);

    }
}
