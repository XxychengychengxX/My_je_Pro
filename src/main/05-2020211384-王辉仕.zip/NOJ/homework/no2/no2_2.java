package homework.no2;

import java.util.Arrays;

public class no2_2 {
    public static void main(String[] args) {
        int[] ints = new int[100];
        int[][] ints1 = new int[10][10];
//        for (int i = 0; i < ints.length; i++)
//            ints[i] = (int) (Math.random() * 100);
//        Arrays.sort(ints);
//        System.out.println(Arrays.toString(ints));

        for (int i = 0; i < ints1.length; i++)
            for (int j = 0; j < ints1[0].length; j++)
            ints1[i][j] = (int) (Math.random() * 100);
        twoperspectivearraybubblesort(ints1);
        System.out.println(Arrays.deepToString(ints1));

        /*select sort*/
        for (int i = 0; i < ints.length; i++)
            ints[i] = (int) (Math.random() * 100);
        for (int i = 0; i < ints.length; i++) {
            int mins = i;
            for (int j = i; j < ints.length; j++) {
                if (ints[mins] > ints[j]) mins = j;
                int temp;
                temp = ints[mins];
                ints[mins] = ints[i];
                ints[i] = temp;
            }
        }
        System.out.println(Arrays.toString(ints));


        /*bubble sort*/
        for (int i = 0; i < ints.length; i++)
            ints[i] = (int) (Math.random() * 100);
        for (int i = ints.length; i > 0; i--) {
            for (int j = 0; j < i - 1; j++) {
                if (ints[j + 1] < ints[j]) {
                    int temp = ints[j + 1];
                    ints[j + 1] = ints[j];
                    ints[j] = temp;
                }
            }
        }
        System.out.println(Arrays.toString(ints));
    }


    /*search*/
    public static int search1(int[] ints, int target) {
        Arrays.sort(ints);
        return Arrays.binarySearch(ints, target);
    }

    public static int search2(int[] ints, int target) {
        for (int i = 0; i < ints.length; i++) {
            if (ints[i] == target) return i;
        }
        return -1;
    }


    /*wether same*/
    public static boolean sameas(int[] ints1, int[] ints2) {
        if (ints1.length != ints2.length) return false;
        int i = 0;
        for (int j : ints1) {
            if (j != ints2[i]) return false;
            else i++;
        }
        return true;
    }

    /*fill all array*/
    public static void fill(int[] ints) {
        Arrays.fill(ints, 22);
    }

    /*twoperspectivesort*/
    public static void twoperspectivearraybubblesort(int[][] ints) {
        for (int i = 1; i <= ints.length * ints[0].length; i++)
            for (int j = i / ints[0].length; j < ints.length-1; j++) {
                for (int k = i % ints.length - 1; k < ints[0].length  ; k++) {
                    if (k == ints[0].length -1 && j != ints.length -1) {
                        if (ints[j][k] > ints[j+1][0]) {
                            int temp = ints[j][k];
                            ints[j][k] =ints[j+1][0];
                            ints[j+1][0] = temp;

                        }} else {
                            if (ints[j][k + 1] < ints[j][k]) {
                                int temp = ints[j][k + 1];
                                ints[j][k + 1] = ints[j][k];

                                ints[j][k] = temp;
                            }
                        }

                }
        /* for (int i = 0; i < ints.length; i++) {
            int mins = i;
            for (int j = i; j < ints.length; j++) {
                if (ints[mins] > ints[j]) mins = j;
                int temp;
                temp = ints[mins];
                ints[mins] = ints[i];
                ints[i] = temp;
            }
        }*/
            }
    }

    public static void twoperspectivearraycopysort(int[][] ints) {
        int i = 0;
        int[] ints1 = new int[ints.length * ints[0].length];
        for (int[] anInt : ints) {
            System.arraycopy(anInt, 0, ints1, i * anInt.length, anInt.length);
            i++;
        }
        Arrays.sort(ints);
        for (int j = 0; j < ints.length; j++)
            for (int k = 0, s = 0; k < ints[0].length; s++, k++) {
                ints[j][k] = ints1[s];
            }
    }


}
