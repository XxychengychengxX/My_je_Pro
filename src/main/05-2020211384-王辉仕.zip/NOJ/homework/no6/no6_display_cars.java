package homework.no6;

public class no6_display_cars implements no6_display {
    int gas;

    public int getGas() {
        return gas;
    }

    public void setGas(int gas) {
        this.gas = gas;
    }

    public no6_display_cars(int gas) {
        this.gas = gas;
    }

    @Override
    public void display() {
        System.out.println("汽车油量：" + this.gas);
    }
}
